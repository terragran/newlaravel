<?php

class LinksSeeder extends Seeder {

    public function run()
    {
        DB::table('options')->insert(array(
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
            array('url' => str_random(), 'type' => 'embed', 'approved' => 0, 'label' => str_random(), 'title_id' => 314),
        ));
    }

}