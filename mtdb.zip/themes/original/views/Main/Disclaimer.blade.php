@extends('Main.Boilerplate')

@section('bodytag')
	<body id="privacy">
@stop

@section('content')

    <div class="container push-footer-wrapper">

    	{{ trans('disclaimer.disclaimer') }}

	<div class="push"></div>
    </div>

@stop


