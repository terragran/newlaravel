@extends('Main.BoilerplateNOJSvagas')
<?php 
	$ur=explode('/', str_replace('-',' ',$_SERVER["REQUEST_URI"]));
	$urstate=last(explode('-', $_SERVER["REQUEST_URI"]));
	$urcityy=explode('/', $_SERVER["REQUEST_URI"]);
	$urcityyy=explode('-', ucwords(strtolower($urcityy[1])));
	list($firstalerta)=explode('?', $urcityy[1]);
	list($firstalerta2)=explode('?', $firstalerta);
	list($first)=explode('-', $urcityy[1]);
	
	$urcityyy=explode('-', ucwords(strtolower($urcityy[1])));
	list($firstum)=explode('-', $urcityy[1]);
	/*
	list($_, $_,$_, $fourth)=explode('-', $urcityy[2]);
	list($_, $_,$_,$_, sizeof($fifth)-1)=explode('-', $urcityy[2]);
	list($_, $_,$_,$_,$_, $sixth)=explode('-', $urcityy[2]);
	list($_, $_,$_,$_,$_,$_, $seven)=explode('-', $urcityy[2]);
	
	$urcityyyy=ucwords(strtolower($third)).' '.ucwords(strtolower($fourth)).' '.ucwords(strtolower($fifth)).' '.ucwords(strtolower($sixth)).' '.ucwords(strtolower($seven));
			*/
			//$genre = (isset(ucwords(strtolower($urcityyy[4]))) ? ucwords(strtolower($urcityyy[4])) : null).
			
			if(!empty($urcityyy[0]) ? $urcityyy[0] : null){
			$urcityyyy=	ucwords(strtolower((!empty($urcityyy[1]) ? $urcityyy[1] : null).' '.(!empty($urcityyy[2]) ? $urcityyy[2] : null)));			
			}
			if(!empty($urcityyy[1]) ? $urcityyy[1] : null){
			$urcityyyy=	ucwords(strtolower((!empty($urcityyy[1]) ? $urcityyy[1] : null).' '.(!empty($urcityyy[2]) ? $urcityyy[2] : null)));			
			}
			if(!empty($urcityyy[2]) ? $urcityyy[2] : null){
			$urcityyyy=	ucwords(strtolower((!empty($urcityyy[1]) ? $urcityyy[1] : null).' '.(!empty($urcityyy[2]) ? $urcityyy[2] : null)));		
			}
			if(!empty($urcityyy[3]) ? $urcityyy[3] : null){
			$urcityyyy=	ucwords(strtolower((!empty($urcityyy[2]) ? $urcityyy[2] : null).' '.(!empty($urcityyy[3]) ? $urcityyy[3] : null)));	
			}
			
			if(!empty($urcityyy[4]) ? $urcityyy[4] : null){
			$urcityyyy=	ucwords(strtolower((!empty($urcityyy[2]) ? $urcityyy[2] : null).' '.(!empty($urcityyy[3]) ? $urcityyy[3] : null).' '.(!empty($urcityyy[4]) ? $urcityyy[4] : null)));	
			}
			
			if(!empty($urcityyy[5]) ? $urcityyy[5] : null){
			$urcityyyy=	ucwords(strtolower((!empty($urcityyy[2]) ? $urcityyy[2] : null).' '.(!empty($urcityyy[3]) ? $urcityyy[3] : null).' '.(!empty($urcityyy[4]) ? $urcityyy[4] : null).' '.(!empty($urcityyy[5]) ? $urcityyy[5] : null)));
			}
			if(!empty($urcityyy[6]) ? $urcityyy[6] : null){
			$urcityyyy=	ucwords(strtolower((!empty($urcityyy[2]) ? $urcityyy[2] : null).' '.(!empty($urcityyy[3]) ? $urcityyy[3] : null).' '.(!empty($urcityyy[4]) ? $urcityyy[4] : null).' '.(!empty($urcityyy[5]) ? $urcityyy[5] : null).' '.(!empty($urcityyy[6]) ? $urcityyy[6] : null)));
			}
			if(!empty($urcityyy[7]) ? $urcityyy[7] : null){
			$urcityyyy=	ucwords(strtolower((!empty($urcityyy[2]) ? $urcityyy[2] : null).' '.(!empty($urcityyy[3]) ? $urcityyy[3] : null).' '.(!empty($urcityyy[4]) ? $urcityyy[4] : null).' '.(!empty($urcityyy[5]) ? $urcityyy[5] : null).' '.(!empty($urcityyy[6]) ? $urcityyy[6] : null).' '.(!empty($urcityyy[7]) ? $urcityyy[7] : null)));
			
				
			}
			$urcityyyyvai=	ucwords(strtolower((!empty($urcityyy[2]) ? $urcityyy[2] : null).' '.(!empty($urcityyy[3]) ? $urcityyy[3] : null).' '.(!empty($urcityyy[4]) ? $urcityyy[4] : null).' '.(!empty($urcityyy[5]) ? $urcityyy[5] : null).' '.(!empty($urcityyy[6]) ? $urcityyy[6] : null).' '.(!empty($urcityyy[7]) ? $urcityyy[7] : null)).' '.(!empty($urcityyy[8]) ? $urcityyy[8] : null).' '.(!empty($urcityyy[9]) ? $urcityyy[9] : null).' '.(!empty($urcityyy[10]) ? $urcityyy[10] : null));
			$urcityyyyvai2=	ucwords(strtolower((!empty($urcityyy[0]) ? $urcityyy[0] : null).' '.(!empty($urcityyy[1]) ? $urcityyy[1] : null).' '.(!empty($urcityyy[2]) ? $urcityyy[2] : null).' '.(!empty($urcityyy[3]) ? $urcityyy[3] : null).' '.(!empty($urcityyy[4]) ? $urcityyy[4] : null).' '.(!empty($urcityyy[5]) ? $urcityyy[5] : null).' '.(!empty($urcityyy[6]) ? $urcityyy[6] : null).' '.(!empty($urcityyy[7]) ? $urcityyy[7] : null)));
	?>
@section('bodytag')
    <body id="titles-index" style="width:100%">
@stop
<script type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
    </script>
@section('assets')
    @parent

    <meta name="fragment" content="!"/>
    <meta name="title" content="{{ trans('main.meta title') }}"/>
    <meta name="description" content="{{ trans('main.meta description') }}"/>
    <meta name="keywords" content="{{ trans('main.meta keywords') }}"/>

    {{ HTML::style('themes/mercury/assets/css/pikaday.css') }}
@stop

@section('content')
<div class="hidden-xs"><br><br><br><br><br><br><br><br></div>
    <div class="page-wrapper" style="background-color:#FFFFFF; width:100%">
        <header class="header" style="background-color:#FFFFFF; width:100%">
            <div class="overlay" style="background-color:#FFFFFF; width:100%"><center>@include('Partials.adsense')</center></div>
        </header>
<br><br><br><br><br>
        <div class="container" id="content" style="width:95%">

            <div class="clearfix">
                <div class="index-pagination">{{ $data->links() }}</div>
				
            </div>
			@include('Partials.Response')

<center><h1>{{--({{  number_format($data->getTotal() )}})--}} Vagas de emprego @if(str::slug($urcityyyyvai))em @endif
		@if(!empty($category))	{{str::title($category)}} ,@endif    @if($first!='empregos'){{str::title(str_replace('_',' ',$first))}}, @endif {{ucfirst($urcityyyyvai)}}</h1>
		<center><h5>Boas-vindas, esperamos ter a vaga de emprego que procura @if(str::slug($urcityyyyvai))em {{ucfirst($urcityyyyvai)}}@endif. Boa sorte!</h5></center><br></center>
            <div class="row">
                <section data-bind="foreach: {data: sourceItems, afterRender: lazyLoadImage}" class="col-sm-8">
				
		@if( count( $data ) > 0 )
					@foreach( $data->slice(0,3) as $cl )
						
							<figure class="col-lg-4 col-md-6 col-sm-8 pretty-figure" style=" padding-left:10px">
						    	

							  	<div title="{{{ $cl->title }}}" style=" padding-left:10px; background-color: #F2F2F2; height:210" >
							  		
									
									<div style="background-color:#1796B7; color:#FFFFFF ; width:100%; height:60px; padding-top:5px">
								
									<a style="color:#FFFFFF" href="https://www.havagas.com.br/{{str::slug($first)}}-em-{{ Str::slug($cl->city) }}/{{ $cl->id }}-{{ Str::slug($cl->title) }}"><center><h4>@if ($cl->banco_talentos) (Banco de talentos) @elseif ($cl->status=='preenchida') (Vaga preenchida) @endif {{ str::title(str_limit($cl->title,50)) }} </h4></center></a>
								
									</div>
									
									{{ strip_tags(str_limit($cl->plot,80)) }}<br>
									@if($cl->category!='Empregos') {{ $cl->category }} @endif
									 @if(!str::slug($urcityyyyvai))
									 <i class="fa fa-map-marker" aria-hidden="true"></i> {{ $cl->city }} {{ $cl->state }}  @if($cl->salary)<i class="fa fa-money" aria-hidden="true"></i> {{$cl->salary}} @endif @if($cl->job_type) <i class="fa fa-briefcase" aria-hidden="true"></i>  {{$cl->job_type}} @endif <a class="li" href="/empregos-em-{{ str::slug($cl->city) }}/{{ str::slug($cl->bairro) }}">{{$cl->bairro}}</a>
									 @else
									<i class="fa fa-map-marker" aria-hidden="true"></i> 	{{ $cl->city }} {{ $cl->state }} @if($cl->salary)<i class="fa fa-money" aria-hidden="true"></i> {{$cl->salary}} @endif @if($cl->job_type) <i class="fa fa-briefcase" aria-hidden="true"></i>  {{$cl->job_type}} @endif <a class="li" href="/empregos-em-{{ str::slug($cl->city) }}/{{ str::slug($cl->bairro) }}">{{$cl->bairro}}</a>
									@endif<br>
									
									 {{ date( 'd/m/Y' , strtotime($cl->created_at))}}
									


									<br>
									<input type="hidden" id="place_id" name="place_id" value="{{ $cl->id }}">
								  <input type="hidden" id="description" name="description" value="{{ $cl->plot }}">
					<?php 
			$fav = DB::table('favoritos')
                     ->select('id','place_id','userid')
                     ->where('place_id', '=',  $cl->id)
					 ->where('userid', '=',  !empty(Sentry::getUser()->id) ? Sentry::getUser()->id : null)
                     ->get();
			?>
			
			@if ($fav)
															
	 	 			<span id="desk-favourites-block-{{ $cl->id }}" ><a target="_blank" class="btn" title="Ver favoritos" alt="Salvar vaga {{ $cl->title }}" href="/meusfavoritos/mine/">
<i class="fa fa-heart"></i></a></span> 
					@else
					<span id="desk-favourites-block-{{ $cl->id }}" ><a class="btn" alt="Salvar vaga {{ $cl->title }}" " title="salvar para ver depois" href="/favoritos/add/{{ $cl->id }}">
<i class="fa fa-heart-o"></i></a></span>
					@endif
									@if (Helpers::hasSuperAccess())
									<a href="/news/{{ $cl->id }}/edit">Editar</a><br>
									
								
 
 <a target="_blank" href="https://www.havagas.com.br/edit/index.php?url=https://www.havagas.com.br/empregos-em-{{ Str::slug($cl->city)}}/{{ $cl->id }}-{{ Str::slug($cl->title) }}&method=URL_UPDATED&submit="><strong>Enviar Google</strong></a>
  

									@endif
							  	</div>
								<div style="clear:both"></div>
						    </figure>
							<figure class="col-lg-3 col-md-4 col-sm-6 pretty-figure" style=" padding-left:5px;">
								<div title="{{{ $cl->title }}}" style=" padding-left:10px; background-color: #F7F7F7; height:210" >
						<style>
.respons-havagas-topo { width: 250px; height: 170px; }
@media(min-width: 500px) { .respons-havagas-topo { width: 350px; height: 170px; } }
@media(min-width: 800px) { .respons-havagas-topo { width: 350px; height: 170px; } }
</style>


<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 970x250 --><!-- soumoc-busca -->
<ins class="adsbygoogle respons-havagas-topo"
     style="display:inline-block"
     data-ad-client="ca-pub-8835124773225705"
     data-ad-slot="6588849272"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<div style="clear:both"></div><br>
</div>
  </figure>
					@endforeach
		
				@foreach( $data->slice(4,15) as $cl )
						
							<figure class="col-lg-3 col-md-4 col-sm-6 pretty-figure" style=" padding-left:5px;">
						    	

							  	<div title="{{{ $cl->title }}}"  style=" padding-left:10px; background-color: #F2F2F2; height:210; width:100%" >
							  		
									<div style="background-color:#1796B7; color:#FFFFFF ; height:60px; padding-top:5px; width:100%">
									
									<a style="color:#FFFFFF" href="https://www.havagas.com.br/{{str::slug($first)}}-em-{{ Str::slug($cl->city) }}/{{ $cl->id }}-{{ Str::slug($cl->title) }}"><center><h4>@if ($cl->banco_talentos) (Banco de talentos) @elseif ($cl->status=='preenchida') (Vaga preenchida) @endif {{ str::title(str_limit($cl->title,50)) }} </h4></center></a>
									
									</div>
									{{ strip_tags(str_limit($cl->plot,80)) }}<br><br>
										@if($cl->category!='Empregos') {{ $cl->category }} @endif
									 @if(!str::slug($urcityyyyvai))
									<i class="fa fa-briefcase" aria-hidden="true"></i>  {{ $cl->city }} {{ $cl->state }}  @if($cl->salary)<i class="fa fa-money" aria-hidden="true"></i> {{$cl->salary}} @endif @if($cl->job_type)   {{$cl->job_type}} @endif <a class="li" href="/empregos-em-{{ str::slug($cl->city) }}/{{ str::slug($cl->bairro) }}">{{$cl->bairro}}</a>
									 @else
									 <i class="fa fa-map-marker" aria-hidden="true"></i> 	{{ $cl->city }} {{ $cl->state }} @if($cl->salary)<i class="fa fa-money" aria-hidden="true"></i> {{$cl->salary}} @endif @if($cl->job_type) <i class="fa fa-briefcase" aria-hidden="true"></i>  {{$cl->job_type}} @endif <a class="li" href="/empregos-em-{{ str::slug($cl->city) }}/{{ str::slug($cl->bairro) }}">{{$cl->bairro}}</a>
									@endif
									<br>
									{{ date( 'd/m/Y' , strtotime($cl->created_at)),' ', '(',$cl->created_at->diffForHumans(),')'}}
									<br>
									<input type="hidden" id="place_id" name="place_id" value="{{ $cl->id }}">
								  <input type="hidden" id="description" name="description" value="{{ $cl->plot }}">
					<?php 
			$fav = DB::table('favoritos')
                     ->select('id','place_id','userid')
                     ->where('place_id', '=',  $cl->id)
					 ->where('userid', '=',  !empty(Sentry::getUser()->id) ? Sentry::getUser()->id : null)
                     ->get();
			?>
			
			@if ($fav)
															
	 	 			<span id="desk-favourites-block-{{ $cl->id }}" ><a target="_blank" class="btn" title="Ver favoritos" alt="Salvar vaga {{ $cl->title }}" href="/meusfavoritos/mine/">
<i class="fa fa-heart"></i></a></span> 
					@else
					<span id="desk-favourites-block-{{ $cl->id }}" ><a class="btn" alt="Salvar vaga {{ $cl->title }}" " title="salvar para ver depois" href="/favoritos/add/{{ $cl->id }}">
<i class="fa fa-heart-o"></i></a></span>
					@endif
									@if (Helpers::hasSuperAccess())
									<a href="/news/{{ $cl->id }}/edit">Editar</a><br>
									
								
 
 <a target="_blank" href="https://www.havagas.com.br/edit/index.php?url=https://www.havagas.com.br/empregos-em-{{ Str::slug($cl->city)}}/{{ $cl->id }}-{{ Str::slug($cl->title) }}&method=URL_UPDATED&submit="><strong>Enviar Google</strong></a>
  

									@endif
									
							  	</div>
								<div style="clear:both"></div>
						    </figure>
						
					@endforeach
								@foreach( $data->slice(18,3) as $cl )
						
							<figure class="col-lg-3 col-md-4 col-sm-6 pretty-figure" style=" padding-left:5px;">
						    	

							  	<div title="{{{ $cl->title }}}" style=" padding-left:10px; background-color: #F2F2F2; height:210" >
							  		
									
									<div style="background-color:#1796B7; color:#FFFFFF ; height:60; padding-top:5px">
								@if($cl->city=='Porto Alegre')
									<a style="color:#FFFFFF" href="https://poa.havagas.com.br/{{str::slug($first)}}-em-{{ Str::slug($cl->city) }}/{{ $cl->id }}-{{ Str::slug($cl->title) }}"><center><h4>{{ str::title(str_limit($cl->title,50)) }} </h4></center></a>
									@elseif($cl->city=='Montes Claros')
									<a style="color:#FFFFFF" href="https://moc.havagas.com.br/{{str::slug($first)}}-em-{{ Str::slug($cl->city) }}/{{ $cl->id }}-{{ Str::slug($cl->title) }}"><center><h4>{{ str::title(str_limit($cl->title,50)) }} </h4></center></a>
									
									@elseif($cl->city=='Belo Horizonte')
									<a style="color:#FFFFFF" href="https://bh.havagas.com.br/{{str::slug($first)}}-em-{{ Str::slug($cl->city) }}/{{ $cl->id }}-{{ Str::slug($cl->title) }}"><center><h4>{{ str::title(str_limit($cl->title,50)) }} </h4></center></a>
									@else
									<a style="color:#FFFFFF" href="https://www.havagas.com.br/{{str::slug($first)}}-em-{{ Str::slug($cl->city) }}/{{ $cl->id }}-{{ Str::slug($cl->title) }}"><center><h4>{{ str::title(str_limit($cl->title,50)) }} </h4></center></a>
									@endif
									</div><h5>
									{{ strip_tags(str_limit($cl->plot,80)) }}<br><br>
									@if($cl->category!='Empregos') {{ $cl->category }} @endif
									 @if(!str::slug($urcityyyyvai))
									 <i class="fa fa-map-marker" aria-hidden="true"></i> {{ $cl->city }} {{ $cl->state }} @if($cl->salary)<i class="fa fa-money" aria-hidden="true"></i> {{$cl->salary}} @endif @if($cl->job_type) <i class="fa fa-briefcase" aria-hidden="true"></i>  {{$cl->job_type}} @endif <a class="li" href="/empregos-em-{{ str::slug($cl->city) }}/{{ str::slug($cl->bairro) }}">{{$cl->bairro}}</a>
									 @else
									<i class="fa fa-map-marker" aria-hidden="true"></i> {{ $cl->city }} {{ $cl->state }} @if($cl->salary)<i class="fa fa-money" aria-hidden="true"></i> {{$cl->salary}} @endif @if($cl->job_type) <i class="fa fa-briefcase" aria-hidden="true"></i>  {{$cl->job_type}} @endif <a class="li" href="/empregos-em-{{ str::slug($cl->city) }}/{{ str::slug($cl->bairro) }}">{{$cl->bairro}}</a>
									<br>
									{{ date( 'd/m/Y' , strtotime($cl->created_at)),' ', '(',$cl->created_at->diffForHumans(),')'}}
									<br>
									<input type="hidden" id="place_id" name="place_id" value="{{ $cl->id }}">
								  <input type="hidden" id="description" name="description" value="{{ $cl->plot }}">
					<?php 
			$fav = DB::table('favoritos')
                     ->select('id','place_id','userid')
                     ->where('place_id', '=',  $cl->id)
					 ->where('userid', '=',  !empty(Sentry::getUser()->id) ? Sentry::getUser()->id : null)
                     ->get();
			?>
			
			@if ($fav)
															
	 	 			<span id="desk-favourites-block-{{ $cl->id }}" ><a target="_blank" class="btn" title="Ver favoritos" alt="Salvar vaga {{ $cl->title }}" href="/meusfavoritos/mine/">
<i class="fa fa-heart"></i></a></span> 
					@else
					<span id="desk-favourites-block-{{ $cl->id }}" ><a class="btn" alt="Salvar vaga {{ $cl->title }}" " title="salvar para ver depois" href="/favoritos/add/{{ $cl->id }}">
<i class="fa fa-heart-o"></i></a></span>
					@endif
									@endif
									@if (Helpers::hasSuperAccess())
									<a href="/news/{{ $cl->id }}/edit">Editar</a><br>
									
								
 
 <a target="_blank" href="https://www.havagas.com.br/edit/index.php?url=https://www.havagas.com.br/empregos-em-{{ Str::slug($cl->city)}}/{{ $cl->id }}-{{ Str::slug($cl->title) }}&method=URL_UPDATED&submit="><strong>Enviar Google</strong></a>
  

									@endif
							  	</div>
						    </figure>
							<figure class="col-lg-3 col-md-4 col-sm-6 pretty-figure" style=" padding-left:5px;">
								<div title="{{{ $cl->title }}}" style=" padding-left:10px; background-color: #F7F7F7; height:210" >
						<style>
.respons-havagas-topo { width: 250px; height: 170px; }
@media(min-width: 500px) { .respons-havagas-topo { width: 250px; height: 170px; } }
@media(min-width: 800px) { .respons-havagas-topo { width: 250px; height: 170px; } }
</style>


<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 970x250 --><!-- soumoc-busca -->
<ins class="adsbygoogle respons-havagas-topo"
     style="display:inline-block"
     data-ad-client="ca-pub-8835124773225705"
     data-ad-slot="6588849272"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
<div style="clear:both"></div>
  </figure>
					@endforeach
					@endif
                  
                      
                    
                </section>
                <div class="filter-panel col-sm-3 col-sm-offset-1">
                    {{-- Hooks::renderHtml('Titles.Index.UnderFilters') --}}
                    <div class="filter-label">{{trans('dash.genres')}}</div>
                    <div class="genre-box">
                        @foreach ($options->getGenresEmpregos() as $genre)
                            <div class="checkbox">
                                <label>
								@if(str::slug($urcityyyyvai) )
								<a class="" href="/empregos-em-{{str::slug($urcityyyyvai)}}/{{str::slug($genre)}}">
                                    <input type="checkbox" class="checkbox" value="{{strtolower($genre)}}" onchange="MM_jumpMenu('parent',this,0)"/> </a>{{ $genre }}
									@else
									
									<a class="" href="/empregos-em-{{str::slug($genre)}}">
                                    <input type="checkbox" class="checkbox" value="{{strtolower($genre)}}" onchange="MM_jumpMenu('parent',this,0)"/> </a>{{ $genre }}
									@endif
                                </label>
                            </div>
                        @endforeach
                    </div>
					@if(str::slug($urcityyyyvai) )
					 <div class="filter-label">Bairro</div>
					<div class="form-group">
					<select name="genres" class="form-control" data-bind="value: genre" onchange="MM_jumpMenu('parent',this,0)">
				<option value="">Bairros</option>
					@foreach ($bairrocity as $tipo)
						<option value="/empregos-em-{{str::slug($urcityyyyvai)}}/{{str::slug($tipo->bairro)}}">{{ $tipo->bairro }}</option>
					
					@endforeach
					
			</select>
			</div>
			
			@endif
			 <div class="filter-label">Cidades</div>
				
			 <div class="genre-box">
					@foreach ($cityindex as $tipo)
					 <div class="checkbox">
					<a class="" href="/empregos-em-{{str::slug($tipo->city)}}">
                                    <input type="checkbox" class="checkbox" value="{{strtolower($tipo->city)}}" onchange="MM_jumpMenu('parent',this,0)"/> </a>{{ $tipo->city }}
									</div>
					@endforeach
					
	
			</div>
					<style>
.respons-havagas-topo { width: 350px; height: 170px; }
@media(min-width: 500px) { .respons-havagas-topo { width: 250px; height: 970px; } }
@media(min-width: 800px) { .respons-havagas-topo { width: 250px; height: 970px; } }
</style>


<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 970x250 --><!-- soumoc-busca -->
<ins class="adsbygoogle respons-havagas-topo"
     style="display:inline-block"
     data-ad-client="ca-pub-8835124773225705"
     data-ad-slot="6588849272"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
{{---
                    <div class="form-group border-top">
                        <label for="search">{{ trans('dash.searchByTitle') }}</label>
                        <input type="text" name="search" class="form-control" placeholder="Jurassic World..." data-bind="value: params.query, valueUpdate: 'keyup'">
                    </div>

                    <div class="form-group">
                        <label for="fort">{{ trans('dash.orderBy') }}</label>
                        <select name="sort" class="form-control" data-bind="value: params.order">
                            <option value="release_dateDesc">{{ trans('dash.relDateDesc') }}</option>
                            <option value="release_dateAsc">{{ trans('dash.relDateAsc') }}</option>
                            <option value="mc_user_scoreDesc">{{ trans('dash.rateDesc') }}</option>
                            <option value="mc_user_scoreAsc">{{ trans('dash.rateAsc') }}</option>
                            <option value="mc_num_of_votesDesc">{{ trans('dash.rateNumDesc') }}</option>
                            <option value="mc_num_of_votesAsc">{{ trans('dash.rateNumAsc') }}</option>
                            <option value="titleAsc">{{ trans('dash.titleAsc') }}</option>
                            <option value="titleDesc">{{ trans('dash.titleDesc') }}</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="cast">{{ trans('dash.haveActor') }}</label>
                        <input type="text" name="cast" class="form-control" placeholder="Chris Pratt..." data-bind="value: params.cast, valueUpdate: 'keyup'">
                    </div>

                    <div class="form-group">
                        <label for="date-before">{{ trans('dash.relBefore') }}</label>
                        <input class="form-control date-picker" placeholder="2013-01-05" data-bind="value: params.before, picker: 'before'">
                    </div>

                    <div class="form-group">
                        <label for="date-after">{{ trans('dash.relAfter') }}</label>
                        <input class="form-control date-picker" placeholder="2015-09-15"  data-bind="value: params.after, picker: 'after'">
                    </div>

                    <div class="form-group">
                        <label for="minRating">{{ trans('dash.minRating') }}</label>
                        <select name="minRating" class="form-control" data-bind="value: params.minRating">
                            <option value="">{{trans('dash.any')}}</option>
                            @foreach(range(1, 10) as $num)
                                <option value="{{ $num }}">{{ $num }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="maxRating">{{ trans('dash.maxRating') }}</label>
                        <select name="maxRating" class="form-control" data-bind="value: params.maxRating">
                            <option value="">{{trans('dash.any')}}</option>
                            @foreach(range(1, 10) as $num)
                                <option value="{{ $num }}">{{ $num }}</option>
                            @endforeach
                        </select>
                    </div>
					--}}
                </div>
            </div>

            <div class="clearfix">
                <div class="index-pagination bottom-pagination">{{ $data->links() }}</div>
            </div>

        </div>
    </div>

@stop

@section('scripts')
    <script>
        $('.navbar').affix({
            offset: {
                top: 180
            }
        });

        $('.filter-panel > .checkbox').iCheck({
            checkboxClass: 'icheckbox_square-aero',
            radioClass: 'iradio_square-aero'
        }).on('ifChecked', function(e) {
            app.viewModels.titles.index.params.availToStream(true);
        }).on('ifUnchecked', function(e) {
            app.viewModels.titles.index.params.availToStream(false);
        });

        $('.genre-box .checkbox').iCheck({
            checkboxClass: 'icheckbox_square-aero',
            radioClass: 'iradio_square-aero'
        }).on('ifChecked', function(e) {
            app.viewModels.titles.index.params.genres.push(e.delegateTarget.value);
        }).on('ifUnchecked', function(e) {
            app.viewModels.titles.index.params.genres.remove(e.delegateTarget.value);
        });

       // app.viewModels.titles.index.params.availToStream && app.viewModels.titles.index.params.availToStream(<?php //echo $options->checkAvailToStream(); ?>);
      //app.viewModels.titles.index.start('movie');

        app.paginator.addCallback(function(data) {
            if (data.items && data.items.length) {
                var url    = data.items[0].background.replace('w780', 'original'),
                    mirror = $('.parallax-slider'),
                    background = $('.header');

                if (mirror[0]) {
                    mirror.attr('src', url);
                } else {
                    background.parallax({imageSrc: url, positionY: '0', zIndex: 2});
                }
            }
        });
    </script>
@stop
