<div class="modal fade" id="upload-media-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <button type="button" class="modal-close" data-dismiss="modal" aria-hidden="true"> 
                <span class="fa-stack fa-lg">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-times fa-stack-1x fa-inverse"></i>
                </span>
            </button>
            
            <div class="modal-body">
            	<div class="clearfix">
            		@include('Partials.MediaUploadPage')
            	</div>
            </div>
        </div>
    </div>
</div>